package mx.org.kaana.mantic.correos.beans;

import java.io.File;
import java.io.Serializable;
import java.util.Objects;
import mx.org.kaana.libs.pagina.JsfBase;

/**
 *@company KAANA
 *@project KAJOOL (Control system polls)
 *@date 25/03/2019
 *@time 07:46:52 AM 
 *@author Team Developer 2016 <team.developer@kaana.org.mx>
 */

public class Attachment implements Serializable {

	private static final long serialVersionUID=-6482879638910606700L;
  
	private String id;
	private String name;
	private String path;
	private String absolute;
	private File file;

	public Attachment(String absolute) {
		this.absolute= JsfBase.getApplication().getRealPath(absolute);
		this.init();
	} 

	public Attachment(String id, String absolute) {
		this(absolute);
		this.id= id;
	}

	public Attachment(File file) {
		this.file= file;
		this.init();
	}

	public Attachment(String id, File file) {
		this.file= file;
		this.init();
		this.id= id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id=id;
	}

	public String getName() {
		return name;
	}

	public String getPath() {
		return path;
	}

	public File getFile() {
		return file;
	}
	
	private void init() {
		this.file    = new File(this.absolute);
		this.id      = file.getName();
		if(this.id.contains("."))
			this.id= this.id.substring(0, this.id.indexOf("."));
		this.name    = file.getName();
	}

	@Override
	public int hashCode() {
		int hash=7;
		hash=17*hash+Objects.hashCode(this.id);
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this==obj) {
			return true;
		}
		if (obj==null) {
			return false;
		}
		if (getClass()!=obj.getClass()) {
			return false;
		}
		final Attachment other=(Attachment) obj;
		if (!Objects.equals(this.id, other.id)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Attachment{"+"id="+id+", name="+name+", path="+path+", file="+file+'}';
	}
	
}
